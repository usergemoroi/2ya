/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.common.AdAttributes
 */
package com.yandex.mobile.ads.banner;

import com.yandex.mobile.ads.common.AdAttributes;

public final class a
implements AdAttributes {
    a() {
    }
}

