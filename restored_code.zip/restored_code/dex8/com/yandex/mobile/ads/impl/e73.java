/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  com.yandex.mobile.ads.impl.aa3
 *  com.yandex.mobile.ads.impl.t70
 *  com.yandex.mobile.ads.impl.x70
 */
package com.yandex.mobile.ads.impl;

import android.net.Uri;
import com.yandex.mobile.ads.impl.aa3;
import com.yandex.mobile.ads.impl.t70;
import com.yandex.mobile.ads.impl.wj2;
import com.yandex.mobile.ads.impl.x70;
import java.util.Map;

public final class e73
implements x70 {
    public final t70[] a() {
        return wj2.b();
    }

    public /* synthetic */ t70[] a(Uri uri, Map map2) {
        return aa3.a((x70)this, (Uri)uri, (Map)map2);
    }
}

