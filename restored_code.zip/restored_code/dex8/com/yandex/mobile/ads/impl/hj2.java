/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.fj2
 *  com.yandex.mobile.ads.impl.gj2
 *  com.yandex.mobile.ads.impl.uc1
 *  com.yandex.mobile.ads.impl.wc1
 *  com.yandex.mobile.ads.impl.zq1
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.fj2;
import com.yandex.mobile.ads.impl.gj2;
import com.yandex.mobile.ads.impl.uc1;
import com.yandex.mobile.ads.impl.wc1;
import com.yandex.mobile.ads.impl.zq1;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class hj2
implements gj2 {
    @NotNull
    private final fj2 a;
    @NotNull
    private final wc1 b;

    public hj2(@NotNull fj2 fj22, @NotNull wc1 wc12) {
        this.a = fj22;
        this.b = wc12;
    }

    @Nullable
    public final String a(@NotNull uc1 uc12) {
        this.a.getClass();
        uc12 = fj2.a((uc1)uc12);
        return this.b.a((zq1)uc12);
    }
}

