/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.ex1
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.ex1;

interface hx1
extends ex1 {
    public long a();

    public long a(long var1);

    public static final class a
    extends ex1.b
    implements hx1 {
        @Override
        public final long a() {
            return -1L;
        }

        @Override
        public final long a(long l10) {
            return 0L;
        }
    }
}

