/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.pz$a$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.pz;
import java.lang.reflect.Constructor;

public final class b23
implements pz.a {
    public final Constructor a() {
        return pz.e();
    }
}

