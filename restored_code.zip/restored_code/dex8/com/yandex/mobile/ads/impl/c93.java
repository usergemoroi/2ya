/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.ed
 *  com.yandex.mobile.ads.impl.ed$a
 *  com.yandex.mobile.ads.impl.vr0$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.ed;
import com.yandex.mobile.ads.impl.ew0;
import com.yandex.mobile.ads.impl.vr0;
import com.yandex.mobile.ads.impl.wy;

public final class c93
implements vr0.a {
    public final ed.a a;
    public final ew0 b;
    public final int c;

    public /* synthetic */ c93(ed.a a12, ew0 ew02, int n10) {
        this.a = a12;
        this.b = ew02;
        this.c = n10;
    }

    public final void invoke(Object object) {
        wy.Y(this.a, this.b, this.c, (ed)object);
    }
}

