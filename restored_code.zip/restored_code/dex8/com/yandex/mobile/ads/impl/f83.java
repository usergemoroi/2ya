/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.ed
 *  com.yandex.mobile.ads.impl.ed$a
 *  com.yandex.mobile.ads.impl.vr0$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.ed;
import com.yandex.mobile.ads.impl.vr0;
import com.yandex.mobile.ads.impl.wy;

public final class f83
implements vr0.a {
    public final ed.a a;
    public final boolean b;
    public final int c;

    public /* synthetic */ f83(ed.a a13, boolean bl2, int n10) {
        this.a = a13;
        this.b = bl2;
        this.c = n10;
    }

    public final void invoke(Object object) {
        wy.V(this.a, this.b, this.c, (ed)object);
    }
}

