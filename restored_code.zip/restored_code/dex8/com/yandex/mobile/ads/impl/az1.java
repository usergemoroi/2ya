/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.yo
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.yo;

public final class az1
implements yo {
    public final boolean a() {
        return true;
    }
}

