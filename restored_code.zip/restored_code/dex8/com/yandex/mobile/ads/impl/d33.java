/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  com.yandex.mobile.ads.impl.jj0
 *  com.yandex.mobile.ads.impl.vi0$b
 */
package com.yandex.mobile.ads.impl;

import android.graphics.Bitmap;
import com.yandex.mobile.ads.impl.jj0;
import com.yandex.mobile.ads.impl.rj0;
import com.yandex.mobile.ads.impl.vi0;

public final class d33
implements vi0.b {
    public final rj0 a;
    public final jj0 b;

    public /* synthetic */ d33(rj0 rj02, jj0 jj02) {
        this.a = rj02;
        this.b = jj02;
    }

    public final void a(Bitmap bitmap) {
        rj0.d(this.a, this.b, bitmap);
    }
}

