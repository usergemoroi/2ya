/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.sm$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.gm1;
import com.yandex.mobile.ads.impl.sm;

public final class au2
implements sm.a {
    public final gm1 a;

    public /* synthetic */ au2(gm1 gm12) {
        this.a = gm12;
    }

    public final void a(long l10, long l11, long l13) {
        gm1.a(this.a, l10, l11, l13);
    }
}

