/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.ed
 *  com.yandex.mobile.ads.impl.ed$a
 *  com.yandex.mobile.ads.impl.vr0$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.ed;
import com.yandex.mobile.ads.impl.vr0;
import com.yandex.mobile.ads.impl.wy;

public final class j93
implements vr0.a {
    public final ed.a a;
    public final String b;
    public final long c;
    public final long d;

    public /* synthetic */ j93(ed.a a13, String string2, long l10, long l11) {
        this.a = a13;
        this.b = string2;
        this.c = l10;
        this.d = l11;
    }

    public final void invoke(Object object) {
        wy.K(this.a, this.b, this.c, this.d, (ed)object);
    }
}

