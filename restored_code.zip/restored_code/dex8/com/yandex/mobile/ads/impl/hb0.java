/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.ci1
 *  com.yandex.mobile.ads.impl.fm1
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.ci1;
import com.yandex.mobile.ads.impl.fm1;
import org.jetbrains.annotations.NotNull;

public final class hb0
implements fm1 {
    @NotNull
    private final ci1 a;

    public hb0(@NotNull ci1 ci12) {
        this.a = ci12;
    }

    @NotNull
    public final ci1 a() {
        return this.a;
    }
}

