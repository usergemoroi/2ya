/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.tj1
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.tj1;

public final class f80
implements tj1 {
    private final long a;

    public f80(long l10) {
        this.a = l10;
    }

    public final long a() {
        return this.a;
    }
}

