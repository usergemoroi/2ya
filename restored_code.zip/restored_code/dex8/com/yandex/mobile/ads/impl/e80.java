/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.sj1
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.sj1;

public final class e80
implements sj1 {
    private final long a;

    public e80(long l10) {
        this.a = l10;
    }

    public final long a() {
        return this.a;
    }
}

