/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.ed
 *  com.yandex.mobile.ads.impl.ed$a
 *  com.yandex.mobile.ads.impl.k01
 *  com.yandex.mobile.ads.impl.vr0$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.ed;
import com.yandex.mobile.ads.impl.k01;
import com.yandex.mobile.ads.impl.vr0;
import com.yandex.mobile.ads.impl.wy;

public final class d83
implements vr0.a {
    public final ed.a a;
    public final k01 b;

    public /* synthetic */ d83(ed.a a12, k01 k012) {
        this.a = a12;
        this.b = k012;
    }

    public final void invoke(Object object) {
        wy.A(this.a, this.b, (ed)object);
    }
}

