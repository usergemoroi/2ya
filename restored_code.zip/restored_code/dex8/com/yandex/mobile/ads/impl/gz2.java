/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.hi1$b
 *  com.yandex.mobile.ads.impl.vr0$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.hi1;
import com.yandex.mobile.ads.impl.l60;
import com.yandex.mobile.ads.impl.vr0;

public final class gz2
implements vr0.a {
    public final int a;
    public final hi1.c b;
    public final hi1.c c;

    public /* synthetic */ gz2(int n10, hi1.c c10, hi1.c c11) {
        this.a = n10;
        this.b = c10;
        this.c = c11;
    }

    public final void invoke(Object object) {
        l60.l(this.a, this.b, this.c, (hi1.b)object);
    }
}

