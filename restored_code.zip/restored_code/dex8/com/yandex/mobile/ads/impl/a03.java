/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.b81$a
 *  com.yandex.mobile.ads.impl.i71
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.b81;
import com.yandex.mobile.ads.impl.i71;
import com.yandex.mobile.ads.impl.la;

public final class a03
implements b81.a {
    public final la a;

    public /* synthetic */ a03(la la3) {
        this.a = la3;
    }

    public final boolean a(i71 i712) {
        return la.g(this.a, i712);
    }
}

