/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.kv0
 *  com.yandex.mobile.ads.impl.mv0
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.kv0;
import com.yandex.mobile.ads.impl.mv0;
import java.util.List;

public final class ey2
implements kv0 {
    public final List a(String string2, boolean bl2, boolean bl3) {
        return mv0.a((String)string2, (boolean)bl2, (boolean)bl3);
    }
}

