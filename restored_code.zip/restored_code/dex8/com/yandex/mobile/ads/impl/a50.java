/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  com.yandex.mobile.ads.impl.cp
 */
package com.yandex.mobile.ads.impl;

import android.view.View;
import com.yandex.mobile.ads.impl.cp;
import org.jetbrains.annotations.NotNull;

public final class a50
implements cp {
    public final void a(@NotNull View view) {
        view.setAlpha(0.4f);
        view.setEnabled(false);
    }

    public final void b(@NotNull View view) {
        view.animate().alpha(1.0f).setDuration(200L);
        view.setEnabled(true);
    }
}

