/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.hw0$a
 *  com.yandex.mobile.ads.impl.jx2
 *  com.yandex.mobile.ads.impl.k01$b
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.cc0;
import com.yandex.mobile.ads.impl.hw0;
import com.yandex.mobile.ads.impl.jx2;
import com.yandex.mobile.ads.impl.k01;

public abstract class ei0
implements k01.b {
    public final String b;

    public ei0(String string2) {
        this.b = string2;
    }

    public /* synthetic */ cc0 a() {
        return jx2.a((k01.b)this);
    }

    public /* synthetic */ void a(hw0.a a12) {
        jx2.b((k01.b)this, a12);
    }

    public /* synthetic */ byte[] b() {
        return jx2.c((k01.b)this);
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        return this.b;
    }
}

