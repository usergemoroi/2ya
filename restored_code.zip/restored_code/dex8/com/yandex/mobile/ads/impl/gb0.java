/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.di1
 *  com.yandex.mobile.ads.impl.em1
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.di1;
import com.yandex.mobile.ads.impl.em1;
import org.jetbrains.annotations.NotNull;

public final class gb0
implements em1 {
    @NotNull
    private final di1 a;

    public gb0(@NotNull di1 di12) {
        this.a = di12;
    }

    @NotNull
    public final di1 a() {
        return this.a;
    }
}

