/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.dg
 *  com.yandex.mobile.ads.impl.vf
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.dg;
import com.yandex.mobile.ads.impl.vf;

public final class e32
extends dg<String, String> {
    public final vf a(Object object, String string2) {
        return dg.a((String)string2, (String)"string", (Object)((String)object));
    }
}

