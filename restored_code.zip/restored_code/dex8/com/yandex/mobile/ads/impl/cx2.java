/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.k00$g$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.b62;
import com.yandex.mobile.ads.impl.k00;
import java.util.List;

public final class cx2
implements k00.a {
    public final k00 a;
    public final k00.c b;
    public final boolean c;

    public /* synthetic */ cx2(k00 k002, k00.c c10, boolean bl2) {
        this.a = k002;
        this.b = c10;
        this.c = bl2;
    }

    public final List a(int n10, b62 b622, int[] nArray) {
        return k00.j(this.a, this.b, this.c, n10, b622, nArray);
    }
}

