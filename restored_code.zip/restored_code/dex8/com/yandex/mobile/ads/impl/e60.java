/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.yandex.mobile.ads.impl;

import android.content.Context;
import com.yandex.mobile.ads.impl.m22;

@Deprecated
public final class e60
extends m22 {
    public e60(Context context) {
        super(context);
    }
}

