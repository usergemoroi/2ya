/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.es
 *  kotlin.collections.t
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.es;
import java.util.List;
import kotlin.collections.t;
import org.jetbrains.annotations.NotNull;

final class ds
implements es {
    @NotNull
    public final List a() {
        return t.m();
    }
}

