/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.hi1$b
 *  com.yandex.mobile.ads.impl.vr0$a
 *  com.yandex.mobile.ads.impl.zh1
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.hi1;
import com.yandex.mobile.ads.impl.l60;
import com.yandex.mobile.ads.impl.vr0;
import com.yandex.mobile.ads.impl.zh1;

public final class ez2
implements vr0.a {
    public final zh1 a;

    public /* synthetic */ ez2(zh1 zh12) {
        this.a = zh12;
    }

    public final void invoke(Object object) {
        l60.x(this.a, (hi1.b)object);
    }
}

