/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.k$b
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.k;

final class j
extends k.b<Object> {
    j(k k11) {
        super(k11);
    }

    final Object a(Object object, Object object2) {
        return object2;
    }
}

