/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package com.yandex.mobile.ads.impl;

import android.view.View;
import com.yandex.mobile.ads.impl.cy;
import com.yandex.mobile.ads.impl.zx;
import org.jetbrains.annotations.NotNull;

public final class h30
extends cy<zx.d> {
    public h30(@NotNull View view) {
        super(view);
    }
}

