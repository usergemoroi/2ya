/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.u80
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.a90;
import com.yandex.mobile.ads.impl.u80;

public final class iq2
implements u80 {
    public final a90 a;

    public /* synthetic */ iq2(a90 a902) {
        this.a = a902;
    }

    public final void a(int n10) {
        a90.b(this.a, n10);
    }
}

