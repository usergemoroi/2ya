/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.is
 *  com.yandex.mobile.ads.impl.oq1
 *  kotlin.collections.s0
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.is;
import com.yandex.mobile.ads.impl.oq1;
import java.util.Map;
import kotlin.collections.s0;
import kotlin.z;
import org.jetbrains.annotations.NotNull;

public final class fv
implements oq1 {
    @NotNull
    public final Map<String, Object> a() {
        return s0.g(z.a("ad_type", is.h.b()));
    }
}

