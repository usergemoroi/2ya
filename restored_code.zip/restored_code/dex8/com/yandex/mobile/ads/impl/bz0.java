/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.gh1
 *  com.yandex.mobile.ads.impl.ok0
 *  com.yandex.mobile.ads.impl.u62
 *  com.yandex.mobile.ads.impl.v62
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.az0;
import com.yandex.mobile.ads.impl.f31;
import com.yandex.mobile.ads.impl.gh1;
import com.yandex.mobile.ads.impl.ok0;
import com.yandex.mobile.ads.impl.u62;
import com.yandex.mobile.ads.impl.v62;
import com.yandex.mobile.ads.impl.xo1;
import org.jetbrains.annotations.NotNull;

public final class bz0
implements v62 {
    @NotNull
    public final u62 a(@NotNull f31 f312, @NotNull xo1 xo12, @NotNull ok0 ok02, @NotNull gh1 gh12) {
        return new az0();
    }
}

