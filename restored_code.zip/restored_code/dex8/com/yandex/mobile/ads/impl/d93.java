/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.ed
 *  com.yandex.mobile.ads.impl.ed$a
 *  com.yandex.mobile.ads.impl.ly
 *  com.yandex.mobile.ads.impl.vr0$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.cc0;
import com.yandex.mobile.ads.impl.ed;
import com.yandex.mobile.ads.impl.ly;
import com.yandex.mobile.ads.impl.vr0;
import com.yandex.mobile.ads.impl.wy;

public final class d93
implements vr0.a {
    public final ed.a a;
    public final cc0 b;
    public final ly c;

    public /* synthetic */ d93(ed.a a12, cc0 cc02, ly ly2) {
        this.a = a12;
        this.b = cc02;
        this.c = ly2;
    }

    public final void invoke(Object object) {
        wy.h0(this.a, this.b, this.c, (ed)object);
    }
}

