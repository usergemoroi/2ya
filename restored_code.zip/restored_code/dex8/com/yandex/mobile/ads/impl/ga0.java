/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 */
package com.yandex.mobile.ads.impl;

import android.view.View;
import androidx.recyclerview.widget.RecyclerView;

public abstract class ga0
extends RecyclerView.ViewHolder {
    private ga0(View view) {
        super(view);
    }

    public /* synthetic */ ga0(View view, int n10) {
        this(view);
    }
}

