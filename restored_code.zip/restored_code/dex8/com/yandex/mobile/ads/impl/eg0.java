/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.gj2
 *  com.yandex.mobile.ads.impl.lj2
 *  com.yandex.mobile.ads.impl.tc1
 *  com.yandex.mobile.ads.impl.uc1
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.gj2;
import com.yandex.mobile.ads.impl.lj2;
import com.yandex.mobile.ads.impl.tc1;
import com.yandex.mobile.ads.impl.uc1;
import kotlin.jvm.JvmOverloads;
import org.jetbrains.annotations.NotNull;

public final class eg0
implements lj2<String> {
    @NotNull
    private final gj2 a;

    public /* synthetic */ eg0() {
        this(tc1.a());
    }

    @JvmOverloads
    public eg0(@NotNull gj2 gj22) {
        this.a = gj22;
    }

    public final Object a(uc1 uc12) {
        return this.a.a(uc12);
    }
}

