/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.b81$a
 *  com.yandex.mobile.ads.impl.i71
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.b81;
import com.yandex.mobile.ads.impl.i71;
import com.yandex.mobile.ads.impl.q41;

public final class j23
implements b81.a {
    public final q41 a;

    public /* synthetic */ j23(q41 q412) {
        this.a = q412;
    }

    public final boolean a(i71 i712) {
        return q41.f(this.a, i712);
    }
}

