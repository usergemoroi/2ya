/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.yandex.mobile.ads.impl.ux1
 *  com.yandex.mobile.ads.impl.x2
 *  com.yandex.mobile.ads.impl.zc1
 */
package com.yandex.mobile.ads.impl;

import android.content.Context;
import com.yandex.mobile.ads.impl.kj;
import com.yandex.mobile.ads.impl.lj;
import com.yandex.mobile.ads.impl.q7;
import com.yandex.mobile.ads.impl.ux1;
import com.yandex.mobile.ads.impl.x2;
import com.yandex.mobile.ads.impl.zc1;
import kotlin.jvm.JvmOverloads;
import org.jetbrains.annotations.NotNull;

public final class d3
extends kj<String> {
    @JvmOverloads
    public d3(@NotNull Context context, @NotNull x2 x22, @NotNull String string2, @NotNull String string3, @NotNull lj lj3, @NotNull lj lj4, @NotNull ux1 ux12, @NotNull zc1 zc12, @NotNull q7 q72) {
        super(context, x22, string2, string3, zc12, lj3, lj4, q72, ux12, 3584);
    }
}

