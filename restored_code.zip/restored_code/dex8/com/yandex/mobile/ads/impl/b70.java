/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.i62
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.cc0;
import com.yandex.mobile.ads.impl.i62;

public interface b70
extends i62 {
    public void a(float var1);

    public void a(boolean var1);

    public void c();

    public void d();

    public cc0 e();

    public void f();

    public void g();
}

