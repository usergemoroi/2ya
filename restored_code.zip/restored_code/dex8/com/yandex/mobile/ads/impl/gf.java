/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.yandex.mobile.ads.impl.b8
 *  com.yandex.mobile.ads.impl.f4
 *  com.yandex.mobile.ads.impl.vc0
 *  com.yandex.mobile.ads.impl.x2
 */
package com.yandex.mobile.ads.impl;

import android.content.Context;
import com.yandex.mobile.ads.impl.b8;
import com.yandex.mobile.ads.impl.dg0;
import com.yandex.mobile.ads.impl.f4;
import com.yandex.mobile.ads.impl.oc0;
import com.yandex.mobile.ads.impl.sd0;
import com.yandex.mobile.ads.impl.vc0;
import com.yandex.mobile.ads.impl.x2;
import org.jetbrains.annotations.NotNull;

public final class gf
extends sd0<gf> {
    public gf(@NotNull Context context, @NotNull b8 b82, @NotNull x2 x22, @NotNull oc0 oc02, @NotNull dg0 dg02, @NotNull vc0 vc02) {
        super(context, b82, x22, oc02, vc02, new f4());
        dg02.a((b8<String>)b82);
        dg02.a(x22);
    }

    @Override
    public final sd0 o() {
        return this;
    }
}

