/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.hf0$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.hf0;

public final class if0
implements hf0.a<String> {
    if0() {
    }

    public final Object a(String string2) {
        return string2;
    }
}

