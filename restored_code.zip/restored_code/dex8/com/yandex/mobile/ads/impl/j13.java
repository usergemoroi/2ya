/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.view.View$OnClickListener
 *  com.yandex.mobile.ads.impl.ac0
 *  com.yandex.mobile.ads.impl.ap1
 *  com.yandex.mobile.ads.impl.i71
 *  com.yandex.mobile.ads.impl.no
 *  com.yandex.mobile.ads.impl.no$a
 *  com.yandex.mobile.ads.impl.qr0
 *  com.yandex.mobile.ads.impl.s2
 *  com.yandex.mobile.ads.impl.vf
 */
package com.yandex.mobile.ads.impl;

import android.view.View;
import com.yandex.mobile.ads.impl.ac0;
import com.yandex.mobile.ads.impl.ap1;
import com.yandex.mobile.ads.impl.i71;
import com.yandex.mobile.ads.impl.no;
import com.yandex.mobile.ads.impl.qr0;
import com.yandex.mobile.ads.impl.s2;
import com.yandex.mobile.ads.impl.vf;

public final class j13
implements no {
    public final View.OnClickListener a(vf vf3, qr0 qr02, s2 s24, i71 i712, ap1 ap12, ac0 ac02) {
        return no.a.b((vf)vf3, (qr0)qr02, (s2)s24, (i71)i712, (ap1)ap12, (ac0)ac02);
    }
}

