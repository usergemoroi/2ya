/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.bh1
 *  com.yandex.mobile.ads.impl.ch1
 *  com.yandex.mobile.ads.impl.o4
 *  com.yandex.mobile.ads.impl.p4
 *  kotlin.collections.b1
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.bh1;
import com.yandex.mobile.ads.impl.ch1;
import com.yandex.mobile.ads.impl.o4;
import com.yandex.mobile.ads.impl.p4;
import java.util.LinkedHashMap;
import kotlin.collections.b1;
import org.jetbrains.annotations.NotNull;

public final class cf1
implements ch1 {
    @NotNull
    private final bh1 a;

    public cf1(@NotNull bh1 bh12) {
        this.a = bh12;
    }

    public /* synthetic */ cf1(p4 p42) {
        this(new bh1(p42));
    }

    @NotNull
    public final LinkedHashMap a() {
        return this.a.a(b1.j((Object[])new o4[]{o4.i, o4.k, o4.j, o4.l, o4.m, o4.x, o4.y, o4.z}));
    }
}

