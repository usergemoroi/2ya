/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.a9
 *  com.yandex.mobile.ads.impl.co0
 *  com.yandex.mobile.ads.impl.id2
 *  com.yandex.mobile.ads.impl.zs
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.a9;
import com.yandex.mobile.ads.impl.co0;
import com.yandex.mobile.ads.impl.hm0;
import com.yandex.mobile.ads.impl.id2;
import com.yandex.mobile.ads.impl.zs;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class i5
implements zs {
    @NotNull
    private final a9 a;
    @Nullable
    private zs b;

    public i5(@NotNull a9 a92) {
        this.a = a92;
    }

    public final void a(@NotNull co0 co02) {
        zs zs3 = this.b;
        if (zs3 != null) {
            zs3.a(co02);
        }
    }

    public final void a(@NotNull co0 co02, float f11) {
        zs zs3 = this.b;
        if (zs3 != null) {
            zs3.a(co02, f11);
        }
    }

    public final void a(@NotNull co0 co02, @NotNull id2 id22) {
        zs zs3 = this.b;
        if (zs3 != null) {
            zs3.a(co02, id22);
        }
    }

    public final void a(@Nullable hm0 hm02) {
        this.b = hm02;
    }

    public final void b(@NotNull co0 co02) {
        zs zs3 = this.b;
        if (zs3 != null) {
            zs3.b(co02);
        }
    }

    public final void c(@NotNull co0 co02) {
        zs zs3 = this.b;
        if (zs3 != null) {
            zs3.c(co02);
        }
    }

    public final void d(@NotNull co0 co02) {
        this.a.a();
        zs zs3 = this.b;
        if (zs3 != null) {
            zs3.d(co02);
        }
    }

    public final void e(@NotNull co0 co02) {
        zs zs3 = this.b;
        if (zs3 != null) {
            zs3.e(co02);
        }
    }

    public final void f(@NotNull co0 co02) {
        zs zs3 = this.b;
        if (zs3 != null) {
            zs3.f(co02);
        }
    }

    public final void g(@NotNull co0 co02) {
        zs zs3 = this.b;
        if (zs3 != null) {
            zs3.g(co02);
        }
    }

    public final void h(@NotNull co0 co02) {
        zs zs3 = this.b;
        if (zs3 != null) {
            zs3.h(co02);
        }
    }

    public final void i(@NotNull co0 co02) {
        zs zs3 = this.b;
        if (zs3 != null) {
            zs3.i(co02);
        }
    }
}

