/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.ed
 *  com.yandex.mobile.ads.impl.ed$a
 *  com.yandex.mobile.ads.impl.vr0$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.ed;
import com.yandex.mobile.ads.impl.vr0;
import com.yandex.mobile.ads.impl.wy;

public final class j83
implements vr0.a {
    public final ed.a a;

    public /* synthetic */ j83(ed.a a13) {
        this.a = a13;
    }

    public final void invoke(Object object) {
        wy.L(this.a, (ed)object);
    }
}

