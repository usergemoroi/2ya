/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.cj0
 *  com.yandex.mobile.ads.impl.dj0
 *  com.yandex.mobile.ads.impl.ej0
 *  kotlin.jvm.functions.l
 *  kotlin.jvm.internal.a0
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.cj0;
import com.yandex.mobile.ads.impl.dj0;
import com.yandex.mobile.ads.impl.ej0;
import kotlin.jvm.functions.l;
import kotlin.jvm.internal.a0;

final class g91
extends a0
implements l<ej0, dj0> {
    public static final g91 b = new g91();

    g91() {
        super(1);
    }

    public final Object invoke(Object object) {
        return new dj0((ej0)object, new cj0());
    }
}

