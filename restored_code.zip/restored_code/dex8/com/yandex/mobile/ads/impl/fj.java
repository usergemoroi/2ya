/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.hj
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.hj;

public final class fj
implements hj {
    private final boolean a;
    private final boolean b;

    public fj(boolean bl2, boolean bl3) {
        this.a = bl2;
        this.b = bl3;
    }

    public final boolean a() {
        return this.b;
    }

    public final boolean b() {
        return this.a;
    }
}

