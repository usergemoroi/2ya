/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.tb0
 *  com.yandex.mobile.ads.impl.uk$d
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.tb0;
import com.yandex.mobile.ads.impl.uk;

public final class d13
implements uk.d {
    public final tb0 a;

    public /* synthetic */ d13(tb0 tb02) {
        this.a = tb02;
    }

    public final long a(long l10) {
        return this.a.a(l10);
    }
}

