/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.yandex.mobile.ads.impl.b8
 *  com.yandex.mobile.ads.impl.gh1$b
 *  com.yandex.mobile.ads.impl.gy1
 *  com.yandex.mobile.ads.impl.hk0
 *  com.yandex.mobile.ads.impl.i71
 *  com.yandex.mobile.ads.impl.t91
 *  com.yandex.mobile.ads.impl.u62
 */
package com.yandex.mobile.ads.impl;

import android.content.Context;
import com.yandex.mobile.ads.impl.b8;
import com.yandex.mobile.ads.impl.gh1;
import com.yandex.mobile.ads.impl.gy1;
import com.yandex.mobile.ads.impl.hk0;
import com.yandex.mobile.ads.impl.i71;
import com.yandex.mobile.ads.impl.t91;
import com.yandex.mobile.ads.impl.u62;
import java.util.List;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class az0
implements u62 {
    public final void a(@NotNull Context context, @NotNull gh1.b b10, @Nullable i71 i712) {
    }

    public final void a(@NotNull b8<?> b82, @NotNull List<gy1> list) {
    }

    public final void a(@NotNull gh1.b b10) {
    }

    public final void a(@NotNull hk0 hk02) {
    }

    public final void a(@NotNull i71 i712) {
    }

    public final void a(@NotNull t91 t912) {
    }
}

