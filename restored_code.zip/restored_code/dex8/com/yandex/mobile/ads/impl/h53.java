/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.monetization.ads.mediation.nativeads.MediatedNativeAd
 *  com.yandex.mobile.ads.impl.b8
 *  com.yandex.mobile.ads.impl.vx0$a
 */
package com.yandex.mobile.ads.impl;

import com.monetization.ads.mediation.nativeads.MediatedNativeAd;
import com.yandex.mobile.ads.impl.b8;
import com.yandex.mobile.ads.impl.j61;
import com.yandex.mobile.ads.impl.u71;
import com.yandex.mobile.ads.impl.vx0;

public final class h53
implements vx0.a {
    public final MediatedNativeAd a;
    public final u71 b;
    public final j61 c;

    public /* synthetic */ h53(MediatedNativeAd mediatedNativeAd, u71 u712, j61 j612) {
        this.a = mediatedNativeAd;
        this.b = u712;
        this.c = j612;
    }

    public final void a(b8 b82) {
        u71.b(this.a, this.b, this.c, b82);
    }
}

