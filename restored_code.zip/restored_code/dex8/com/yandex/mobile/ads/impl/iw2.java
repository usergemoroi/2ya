/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.co0
 *  com.yandex.mobile.ads.impl.g5$a
 *  com.yandex.mobile.ads.impl.j5
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.co0;
import com.yandex.mobile.ads.impl.g5;
import com.yandex.mobile.ads.impl.j5;

public final class iw2
implements g5.a {
    public final j5 a;
    public final co0 b;

    public /* synthetic */ iw2(j5 j52, co0 co02) {
        this.a = j52;
        this.b = co02;
    }

    public final void a() {
        j5.d((j5)this.a, (co0)this.b);
    }
}

