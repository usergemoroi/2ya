/*
 * Decompiled with CFR 0.152.
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.dq1;
import org.jetbrains.annotations.Nullable;

public final class dg1
extends dq1 {
    public dg1(@Nullable Exception exception) {
        super(exception);
    }

    public dg1(@Nullable String string2) {
        super(string2);
    }
}

