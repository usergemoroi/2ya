/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.go1
 *  com.yandex.mobile.ads.impl.k42
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.go1;
import com.yandex.mobile.ads.impl.k42;

public final class fo1
extends k42 {
    final go1 e;

    fo1(go1 go12, String string2) {
        this.e = go12;
        super(string2);
    }

    public final long e() {
        return this.e.a(System.nanoTime());
    }
}

