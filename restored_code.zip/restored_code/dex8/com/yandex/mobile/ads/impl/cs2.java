/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.di0$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.di0;

public final class cs2
implements di0.a {
    public final boolean a(int n10, int n12, int n13, int n14, int n15) {
        return di0.c(n10, n12, n13, n14, n15);
    }
}

