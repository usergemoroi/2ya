/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.xo
 *  com.yandex.mobile.ads.impl.yd0
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.wy;
import com.yandex.mobile.ads.impl.xo;
import com.yandex.mobile.ads.impl.yd0;

public final class hu2
implements yd0 {
    public final Object apply(Object object) {
        return new wy((xo)object);
    }
}

