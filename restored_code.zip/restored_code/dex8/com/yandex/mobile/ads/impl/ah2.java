/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.ac0
 *  com.yandex.mobile.ads.impl.xg2
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.ac0;
import com.yandex.mobile.ads.impl.xg2;
import com.yandex.mobile.ads.impl.yg2;
import org.jetbrains.annotations.Nullable;

public final class ah2
implements ac0 {
    @Nullable
    private xg2 a;

    public final void a() {
        xg2 xg22 = this.a;
        if (xg22 != null) {
            xg22.m();
        }
    }

    public final void a(@Nullable yg2 yg22) {
        this.a = yg22;
    }
}

