/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  com.yandex.mobile.ads.impl.vl
 *  com.yandex.mobile.ads.impl.vl$a
 */
package com.yandex.mobile.ads.impl;

import android.os.Bundle;
import com.yandex.mobile.ads.impl.b52;
import com.yandex.mobile.ads.impl.vl;

public final class br2
implements vl.a {
    public final vl fromBundle(Bundle bundle) {
        return b52.d(bundle);
    }
}

