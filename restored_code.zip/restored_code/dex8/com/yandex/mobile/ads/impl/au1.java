/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.s1
 *  com.yandex.mobile.ads.impl.sp1$a
 *  kotlin.collections.s0
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.s1;
import com.yandex.mobile.ads.impl.sp1;
import java.util.Map;
import kotlin.collections.s0;
import kotlin.z;
import org.jetbrains.annotations.NotNull;

public final class au1
implements s1 {
    @NotNull
    public final Map<String, Object> a() {
        return s0.g(z.a("adapter", sp1.a.a));
    }
}

