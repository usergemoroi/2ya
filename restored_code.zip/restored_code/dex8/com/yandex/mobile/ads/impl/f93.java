/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.ed
 *  com.yandex.mobile.ads.impl.ub0
 *  com.yandex.mobile.ads.impl.vr0$b
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.ed;
import com.yandex.mobile.ads.impl.ub0;
import com.yandex.mobile.ads.impl.vr0;
import com.yandex.mobile.ads.impl.wy;

public final class f93
implements vr0.b {
    public final void a(Object object, ub0 ub02) {
        wy.l((ed)object, ub02);
    }
}

