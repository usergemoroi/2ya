/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.z3
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.z3;
import org.jetbrains.annotations.Nullable;

public final class c61
implements z3 {
    @Nullable
    private final String a;

    public c61(@Nullable String string2) {
        this.a = string2;
    }

    @Nullable
    public final String a() {
        return this.a;
    }
}

