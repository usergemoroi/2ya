/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.yandex.mobile.ads.impl.h60$b
 *  com.yandex.mobile.ads.impl.w32
 */
package com.yandex.mobile.ads.impl;

import android.content.Context;
import com.yandex.mobile.ads.impl.h60;
import com.yandex.mobile.ads.impl.w32;

public final class gu2
implements w32 {
    public final Context c;

    public /* synthetic */ gu2(Context context) {
        this.c = context;
    }

    public final Object get() {
        return h60.b.g((Context)this.c);
    }
}

