/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.ca0
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.ca0;
import org.jetbrains.annotations.NotNull;

public final class ba0
extends ca0 {
    @NotNull
    public static final ba0 a = new ba0();

    private ba0() {
        super(0);
    }
}

