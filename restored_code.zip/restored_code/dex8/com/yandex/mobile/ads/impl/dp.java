/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.dg
 *  com.yandex.mobile.ads.impl.hp
 *  com.yandex.mobile.ads.impl.hp$a
 *  com.yandex.mobile.ads.impl.vf
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.dg;
import com.yandex.mobile.ads.impl.hp;
import com.yandex.mobile.ads.impl.vf;

public final class dp
extends dg<hp, String> {
    public final vf a(Object object, String string2) {
        object = (String)object;
        return dg.a((String)string2, (String)"string", (Object)new hp(hp.a.b, (String)object));
    }
}

