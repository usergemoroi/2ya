/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.yandex.mobile.ads.impl.zc
 *  com.yandex.mobile.ads.impl.zd
 */
package com.yandex.mobile.ads.impl;

import android.content.Context;
import com.yandex.mobile.ads.impl.zc;
import com.yandex.mobile.ads.impl.zd;
import org.jetbrains.annotations.NotNull;

public final class dm2
implements zd {
    @NotNull
    private final zc a;

    public /* synthetic */ dm2() {
        this(new zc());
    }

    public dm2(@NotNull zc zc3) {
        this.a = zc3;
    }

    public final void a(@NotNull Context context) {
        this.a.a(context);
    }
}

