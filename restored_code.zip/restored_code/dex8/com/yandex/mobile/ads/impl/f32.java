/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.jg
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.jg;
import kotlin.jvm.internal.y;

public final class f32
implements jg<String> {
    public final boolean a(Object object) {
        boolean bl2 = ((String)(object = (String)object)).length() > 0 && !y.e("null", object);
        return bl2;
    }
}

