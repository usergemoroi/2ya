/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.fj2
 *  com.yandex.mobile.ads.impl.kr1
 *  com.yandex.mobile.ads.impl.lr1
 *  com.yandex.mobile.ads.impl.ou1
 *  com.yandex.mobile.ads.impl.sc1
 *  com.yandex.mobile.ads.impl.uc1
 *  com.yandex.mobile.ads.impl.zq1
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.fj2;
import com.yandex.mobile.ads.impl.kr1;
import com.yandex.mobile.ads.impl.lr1;
import com.yandex.mobile.ads.impl.ou1;
import com.yandex.mobile.ads.impl.sc1;
import com.yandex.mobile.ads.impl.uc1;
import com.yandex.mobile.ads.impl.wp1;
import com.yandex.mobile.ads.impl.zq1;
import org.jetbrains.annotations.NotNull;

public final class cv1
implements lr1<ou1> {
    @NotNull
    private final kr1<ou1> a;
    @NotNull
    private final fj2 b;

    public cv1(@NotNull kr1 kr12, @NotNull fj2 fj22) {
        this.a = kr12;
        this.b = fj22;
    }

    public /* synthetic */ cv1(wp1 wp12) {
        this(sc1.a((wp1)wp12), new fj2());
    }

    public final Object a(uc1 uc12) {
        this.b.getClass();
        uc12 = fj2.a((uc1)uc12);
        return (ou1)this.a.a((zq1)uc12);
    }
}

