/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.yandex.mobile.ads.impl.ej0
 *  com.yandex.mobile.ads.impl.h51
 *  com.yandex.mobile.ads.impl.j51
 *  com.yandex.mobile.ads.impl.u41
 *  com.yandex.mobile.ads.impl.v41
 *  com.yandex.mobile.ads.impl.v51
 *  com.yandex.mobile.ads.impl.w41
 */
package com.yandex.mobile.ads.impl;

import android.content.Context;
import com.yandex.mobile.ads.impl.ej0;
import com.yandex.mobile.ads.impl.h51;
import com.yandex.mobile.ads.impl.j51;
import com.yandex.mobile.ads.impl.u41;
import com.yandex.mobile.ads.impl.v41;
import com.yandex.mobile.ads.impl.v51;
import com.yandex.mobile.ads.impl.w41;
import org.jetbrains.annotations.NotNull;

public final class a02
implements w41 {
    public final void a(@NotNull Context context, @NotNull v41 v412, @NotNull ej0 ej02, @NotNull u41 u412, @NotNull v51 v512, @NotNull h51 h512, @NotNull j51 j512) {
        j512.a(u412.a(context, v412, ej02, v512, h512));
    }
}

