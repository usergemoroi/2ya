/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  com.yandex.mobile.ads.impl.ej0
 *  com.yandex.mobile.ads.impl.jj0
 *  kotlin.jvm.functions.a
 *  kotlin.jvm.internal.a0
 */
package com.yandex.mobile.ads.impl;

import android.graphics.Bitmap;
import com.yandex.mobile.ads.impl.ej0;
import com.yandex.mobile.ads.impl.jj0;
import kotlin.jvm.functions.a;
import kotlin.jvm.internal.a0;

final class d61
extends a0
implements a<Bitmap> {
    final ej0 b;
    final jj0 c;

    d61(ej0 ej02, jj0 jj02) {
        this.b = ej02;
        this.c = jj02;
        super(0);
    }

    public final Object invoke() {
        return this.b.b(this.c);
    }
}

