/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.nr
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.hw1;
import com.yandex.mobile.ads.impl.ji;
import com.yandex.mobile.ads.impl.nr;

public final class fv2
implements nr {
    public final ji a;

    public /* synthetic */ fv2(ji ji3) {
        this.a = ji3;
    }

    public final void e() {
        hw1.j(this.a);
    }
}

