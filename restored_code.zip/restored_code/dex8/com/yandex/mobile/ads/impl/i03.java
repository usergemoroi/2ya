/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  com.yandex.mobile.ads.impl.vl
 *  com.yandex.mobile.ads.impl.vl$a
 */
package com.yandex.mobile.ads.impl;

import android.os.Bundle;
import com.yandex.mobile.ads.impl.mf0;
import com.yandex.mobile.ads.impl.vl;

public final class i03
implements vl.a {
    public final vl fromBundle(Bundle bundle) {
        return mf0.d(bundle);
    }
}

