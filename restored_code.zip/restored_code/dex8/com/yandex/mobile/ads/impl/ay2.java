/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.hm1
 *  com.yandex.mobile.ads.impl.hm1$a
 *  com.yandex.mobile.ads.impl.mi1
 *  com.yandex.mobile.ads.impl.x70
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.hm1;
import com.yandex.mobile.ads.impl.km1;
import com.yandex.mobile.ads.impl.mi1;
import com.yandex.mobile.ads.impl.x70;

public final class ay2
implements hm1.a {
    public final x70 a;

    public /* synthetic */ ay2(x70 x702) {
        this.a = x702;
    }

    public final hm1 a(mi1 mi12) {
        return km1.a.b(this.a, mi12);
    }
}

