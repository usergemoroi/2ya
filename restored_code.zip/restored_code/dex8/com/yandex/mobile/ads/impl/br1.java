/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.cr1
 *  com.yandex.mobile.ads.impl.xw0
 *  okio.e
 *  okio.g
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.cr1;
import com.yandex.mobile.ads.impl.xw0;
import okio.e;
import okio.g;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class br1
extends cr1 {
    final xw0 a;
    final long b;
    final g c;

    br1(long l10, xw0 xw02, e e11) {
        this.a = xw02;
        this.b = l10;
        this.c = e11;
    }

    public final long a() {
        return this.b;
    }

    @Nullable
    public final xw0 b() {
        return this.a;
    }

    @NotNull
    public final g c() {
        return this.c;
    }
}

