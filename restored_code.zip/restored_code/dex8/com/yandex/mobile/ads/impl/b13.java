/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.n92
 *  com.yandex.mobile.ads.impl.q50
 *  com.yandex.mobile.ads.impl.q50$b
 *  com.yandex.mobile.ads.impl.ym
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.n92;
import com.yandex.mobile.ads.impl.q50;
import com.yandex.mobile.ads.impl.ym;

public final class b13
implements q50.b {
    public final q50 a;

    public /* synthetic */ b13(q50 q502) {
        this.a = q502;
    }

    public final q50 a(ym ym3) {
        return n92.c((q50)this.a, (ym)ym3);
    }
}

