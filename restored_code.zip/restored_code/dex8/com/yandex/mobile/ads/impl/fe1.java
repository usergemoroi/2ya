/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.gn
 *  com.yandex.mobile.ads.impl.yq1
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.gn;
import com.yandex.mobile.ads.impl.yq1;
import com.yandex.mobile.ads.impl.zx1;
import java.io.IOException;

final class fe1
implements gn {
    final zx1 a;

    fe1(zx1 zx12) {
        this.a = zx12;
    }

    public final void a(yq1 yq12) {
        this.a.b(yq12);
    }

    public final void a(IOException iOException) {
        this.a.a(iOException);
    }
}

