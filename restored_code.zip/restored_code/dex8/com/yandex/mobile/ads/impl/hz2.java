/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.hi1$b
 *  com.yandex.mobile.ads.impl.vr0$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.ew0;
import com.yandex.mobile.ads.impl.hi1;
import com.yandex.mobile.ads.impl.l60;
import com.yandex.mobile.ads.impl.vr0;

public final class hz2
implements vr0.a {
    public final ew0 a;
    public final int b;

    public /* synthetic */ hz2(ew0 ew02, int n10) {
        this.a = ew02;
        this.b = n10;
    }

    public final void invoke(Object object) {
        l60.r(this.a, this.b, (hi1.b)object);
    }
}

