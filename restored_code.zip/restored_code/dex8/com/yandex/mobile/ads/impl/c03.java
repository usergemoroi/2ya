/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.f60
 *  com.yandex.mobile.ads.impl.f60$c
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.f60;
import com.yandex.mobile.ads.impl.lc0;
import java.util.UUID;

public final class c03
implements f60.c {
    public final f60 a(UUID uUID) {
        return lc0.d(uUID);
    }
}

