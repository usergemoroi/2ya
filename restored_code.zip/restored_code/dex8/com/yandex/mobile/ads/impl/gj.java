/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.gh0
 *  com.yandex.mobile.ads.impl.hf0
 *  com.yandex.mobile.ads.impl.hj
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.gh0;
import com.yandex.mobile.ads.impl.hf0;
import com.yandex.mobile.ads.impl.hj;
import java.util.Map;

public final class gj
implements hj {
    private final boolean a;
    private final boolean b;

    public /* synthetic */ gj(Map map2) {
        hf0.a((Map)map2, (gh0)gh0.d0);
        this(hf0.a((Map)map2, (gh0)gh0.e0), hf0.a((Map)map2, (gh0)gh0.f0));
    }

    public gj(boolean bl2, boolean bl3) {
        this.a = bl2;
        this.b = bl3;
    }

    public final boolean a() {
        return this.b;
    }

    public final boolean b() {
        return this.a;
    }
}

