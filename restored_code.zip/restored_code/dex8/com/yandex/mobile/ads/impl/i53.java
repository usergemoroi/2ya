/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.qx0$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.qx0;
import com.yandex.mobile.ads.impl.s51;
import com.yandex.mobile.ads.impl.u71;

public final class i53
implements qx0.a {
    public final u71 a;

    public /* synthetic */ i53(u71 u712) {
        this.a = u712;
    }

    public final void a(s51 s512) {
        u71.c(this.a, s512);
    }
}

