/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.mq1$a
 *  com.yandex.mobile.ads.impl.yp1
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.ak;
import com.yandex.mobile.ads.impl.mq1;
import com.yandex.mobile.ads.impl.yp1;
import org.jetbrains.annotations.Nullable;

public final class eq1
implements mq1.a {
    public final void a(@Nullable yp1<?> ak3, int n10) {
        if ((ak3 = ak3 instanceof ak ? (ak)ak3 : null) != null && n10 == 3) {
            ak3.w();
        }
    }
}

