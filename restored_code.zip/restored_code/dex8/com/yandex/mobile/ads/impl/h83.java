/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.ed
 *  com.yandex.mobile.ads.impl.ed$a
 *  com.yandex.mobile.ads.impl.vr0$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.ed;
import com.yandex.mobile.ads.impl.vr0;
import com.yandex.mobile.ads.impl.wy;
import java.util.List;

public final class h83
implements vr0.a {
    public final ed.a a;
    public final List b;

    public /* synthetic */ h83(ed.a a13, List list) {
        this.a = a13;
        this.b = list;
    }

    public final void invoke(Object object) {
        wy.E(this.a, this.b, (ed)object);
    }
}

