/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.f3
 *  com.yandex.mobile.ads.impl.mi
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.eu1;
import com.yandex.mobile.ads.impl.f3;
import com.yandex.mobile.ads.impl.mi;
import org.jetbrains.annotations.NotNull;

public final class du1
implements mi {
    final eu1.a a;

    du1(eu1.a a12) {
        this.a = a12;
    }

    public final void a() {
        eu1.a.a(this.a).t();
    }

    public final void a(@NotNull f3 f33) {
        eu1.a.a(this.a).b(f33);
    }
}

