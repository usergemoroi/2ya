/*
 * Decompiled with CFR 0.152.
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.ch0;

public final class dh0
extends ch0 {
    public dh0(String string2) {
        StringBuilder stringBuilder = new StringBuilder("Invalid content type: ");
        stringBuilder.append(string2);
        super(stringBuilder.toString(), 2003);
    }
}

