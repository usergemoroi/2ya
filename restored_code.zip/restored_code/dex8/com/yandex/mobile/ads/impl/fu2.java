/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.w32
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.uz;
import com.yandex.mobile.ads.impl.w32;

public final class fu2
implements w32 {
    public final Object get() {
        return new uz();
    }
}

