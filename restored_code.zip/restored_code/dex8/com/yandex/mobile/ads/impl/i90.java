/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.f3
 *  com.yandex.mobile.ads.impl.mi
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.f3;
import com.yandex.mobile.ads.impl.mi;
import org.jetbrains.annotations.NotNull;

public final class i90
implements mi {
    i90() {
    }

    public final void a() {
    }

    public final void a(@NotNull f3 f33) {
    }
}

