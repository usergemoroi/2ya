/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.widget.ProgressBar
 *  com.yandex.mobile.ads.R$id
 *  com.yandex.mobile.ads.impl.e51
 */
package com.yandex.mobile.ads.impl;

import android.view.View;
import android.widget.ProgressBar;
import com.yandex.mobile.ads.R;
import com.yandex.mobile.ads.impl.e51;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class f51
implements e51 {
    @Nullable
    public final ProgressBar a(@NotNull View view) {
        return null;
    }

    @Nullable
    public final View b(@NotNull View view) {
        return null;
    }

    @Nullable
    public final View c(@NotNull View view) {
        return view.findViewById(R.id.close);
    }
}

