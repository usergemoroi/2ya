/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.a91
 *  com.yandex.mobile.ads.impl.b72$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.a91;
import com.yandex.mobile.ads.impl.b72;

public final class b91
implements b72.a {
    final a91 a;

    b91(a91 a912) {
        this.a = a912;
    }

    public final void a() {
        this.a.j();
    }

    public final void b() {
        this.a.k();
    }
}

