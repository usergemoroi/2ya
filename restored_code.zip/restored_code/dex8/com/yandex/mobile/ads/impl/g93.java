/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.ed
 *  com.yandex.mobile.ads.impl.ed$a
 *  com.yandex.mobile.ads.impl.vr0$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.ed;
import com.yandex.mobile.ads.impl.vr0;
import com.yandex.mobile.ads.impl.wy;

public final class g93
implements vr0.a {
    public final ed.a a;
    public final float b;

    public /* synthetic */ g93(ed.a a13, float f11) {
        this.a = a13;
        this.b = f11;
    }

    public final void invoke(Object object) {
        wy.T(this.a, this.b, (ed)object);
    }
}

