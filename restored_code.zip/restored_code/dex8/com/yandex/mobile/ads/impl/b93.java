/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.ed
 *  com.yandex.mobile.ads.impl.ed$a
 *  com.yandex.mobile.ads.impl.vr0$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.ed;
import com.yandex.mobile.ads.impl.vr0;
import com.yandex.mobile.ads.impl.wy;
import com.yandex.mobile.ads.impl.yu;

public final class b93
implements vr0.a {
    public final ed.a a;
    public final yu b;

    public /* synthetic */ b93(ed.a a12, yu yu2) {
        this.a = a12;
        this.b = yu2;
    }

    public final void invoke(Object object) {
        wy.v(this.a, this.b, (ed)object);
    }
}

