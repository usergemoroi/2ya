/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.hi1$b
 *  com.yandex.mobile.ads.impl.vr0$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.hi1;
import com.yandex.mobile.ads.impl.l60;
import com.yandex.mobile.ads.impl.vr0;

public final class cz2
implements vr0.a {
    public final int a;
    public final int b;

    public /* synthetic */ cz2(int n10, int n12) {
        this.a = n10;
        this.b = n12;
    }

    public final void invoke(Object object) {
        l60.u(this.a, this.b, (hi1.b)object);
    }
}

