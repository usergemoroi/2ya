/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  androidx.annotation.MainThread
 *  com.yandex.mobile.ads.impl.i7
 *  com.yandex.mobile.ads.impl.k4
 */
package com.yandex.mobile.ads.impl;

import androidx.annotation.MainThread;
import com.yandex.mobile.ads.impl.gs1;
import com.yandex.mobile.ads.impl.i7;
import com.yandex.mobile.ads.impl.k4;
import com.yandex.mobile.ads.impl.wn2;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface is1
extends k4<gs1> {
    @MainThread
    public void a();

    @MainThread
    public void a(@NotNull i7 var1);

    @MainThread
    public void a(@Nullable wn2 var1);
}

