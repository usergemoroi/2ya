/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.hi1$b
 *  com.yandex.mobile.ads.impl.vr0$a
 *  com.yandex.mobile.ads.impl.zh1
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.hi1;
import com.yandex.mobile.ads.impl.l60;
import com.yandex.mobile.ads.impl.vr0;
import com.yandex.mobile.ads.impl.zh1;

public final class bz2
implements vr0.a {
    public final zh1 a;
    public final int b;

    public /* synthetic */ bz2(zh1 zh12, int n10) {
        this.a = zh12;
        this.b = n10;
    }

    public final void invoke(Object object) {
        l60.A(this.a, this.b, (hi1.b)object);
    }
}

