/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.eo
 *  com.yandex.mobile.ads.impl.h61
 *  com.yandex.mobile.ads.impl.ht
 *  com.yandex.mobile.ads.impl.t61
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.eo;
import com.yandex.mobile.ads.impl.h61;
import com.yandex.mobile.ads.impl.ht;
import com.yandex.mobile.ads.impl.m71;
import com.yandex.mobile.ads.impl.t61;
import java.util.ArrayList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface c02
extends t61 {
    public void a(@NotNull m71 var1) throws h61;

    public void a(@NotNull m71 var1, @NotNull eo var2) throws h61;

    public void b(@Nullable ht var1);

    @NotNull
    public ArrayList e();
}

