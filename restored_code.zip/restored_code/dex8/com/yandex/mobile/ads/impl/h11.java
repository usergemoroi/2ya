/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.xo0
 *  kotlin.jvm.functions.l
 *  kotlin.jvm.internal.a0
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.xo0;
import kotlin.jvm.functions.l;
import kotlin.jvm.internal.a0;
import kotlin.k0;

final class h11
extends a0
implements l<xo0, k0> {
    public static final h11 b = new h11();

    h11() {
        super(1);
    }

    public final Object invoke(Object object) {
        throw (xo0)object;
    }
}

