/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.ed
 *  com.yandex.mobile.ads.impl.ed$a
 *  com.yandex.mobile.ads.impl.gw0
 *  com.yandex.mobile.ads.impl.vr0$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.ed;
import com.yandex.mobile.ads.impl.gw0;
import com.yandex.mobile.ads.impl.vr0;
import com.yandex.mobile.ads.impl.wy;

public final class i93
implements vr0.a {
    public final ed.a a;
    public final gw0 b;

    public /* synthetic */ i93(ed.a a13, gw0 gw02) {
        this.a = a13;
        this.b = gw02;
    }

    public final void invoke(Object object) {
        wy.j(this.a, this.b, (ed)object);
    }
}

