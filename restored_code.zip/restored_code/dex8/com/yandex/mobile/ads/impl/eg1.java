/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.dj2
 *  com.yandex.mobile.ads.impl.uc1
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.dj2;
import com.yandex.mobile.ads.impl.uc1;

public final class eg1
extends dj2 {
    public eg1(uc1 uc12) {
        super(uc12);
    }

    public eg1(OutOfMemoryError outOfMemoryError) {
        super((Throwable)outOfMemoryError);
    }
}

