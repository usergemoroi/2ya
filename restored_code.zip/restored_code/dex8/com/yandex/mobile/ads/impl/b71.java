/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.a71
 *  com.yandex.mobile.ads.impl.lj2
 *  com.yandex.mobile.ads.impl.lq1
 *  com.yandex.mobile.ads.impl.uc1
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.a71;
import com.yandex.mobile.ads.impl.lj2;
import com.yandex.mobile.ads.impl.lq1;
import com.yandex.mobile.ads.impl.uc1;
import org.jetbrains.annotations.NotNull;

public final class b71
implements lj2<a71> {
    @NotNull
    private final lq1<a71> a;

    public b71(@NotNull lq1<a71> lq12) {
        this.a = lq12;
    }

    public final Object a(uc1 uc12) {
        return (a71)this.a.a(uc12);
    }
}

