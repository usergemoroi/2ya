/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.kq1
 *  com.yandex.mobile.ads.impl.mq1$b
 *  com.yandex.mobile.ads.impl.yp1
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.kq1;
import com.yandex.mobile.ads.impl.mq1;
import com.yandex.mobile.ads.impl.yp1;

public final class cy2
implements mq1.b {
    public final Object a;

    public /* synthetic */ cy2(Object object) {
        this.a = object;
    }

    public final boolean a(yp1 yp12) {
        return kq1.b((Object)this.a, (yp1)yp12);
    }
}

