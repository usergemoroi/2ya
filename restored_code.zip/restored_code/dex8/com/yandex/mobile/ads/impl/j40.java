/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.ex1
 *  com.yandex.mobile.ads.impl.g62
 *  com.yandex.mobile.ads.impl.v70
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.ex1;
import com.yandex.mobile.ads.impl.g62;
import com.yandex.mobile.ads.impl.k40;
import com.yandex.mobile.ads.impl.v70;

public final class j40
implements v70 {
    public final g62 a(int n10, int n13) {
        return new k40();
    }

    public final void a() {
    }

    public final void a(ex1 ex12) {
    }
}

