/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.ar1$a
 *  com.yandex.mobile.ads.impl.dj2
 *  com.yandex.mobile.ads.impl.u21
 *  com.yandex.mobile.ads.impl.u21$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.ar1;
import com.yandex.mobile.ads.impl.dj2;
import com.yandex.mobile.ads.impl.u21;

public final class c53
implements ar1.a {
    public final u21.a c;

    public /* synthetic */ c53(u21.a a12) {
        this.c = a12;
    }

    public final void a(dj2 dj22) {
        u21.c((u21.a)this.c, (dj2)dj22);
    }
}

