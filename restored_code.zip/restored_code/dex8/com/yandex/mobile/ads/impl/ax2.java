/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.k00$g$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.b62;
import com.yandex.mobile.ads.impl.k00;
import java.util.List;

public final class ax2
implements k00.a {
    public final k00.c a;
    public final String b;

    public /* synthetic */ ax2(k00.c c10, String string2) {
        this.a = c10;
        this.b = string2;
    }

    public final List a(int n10, b62 b622, int[] nArray) {
        return k00.e(this.a, this.b, n10, b622, nArray);
    }
}

