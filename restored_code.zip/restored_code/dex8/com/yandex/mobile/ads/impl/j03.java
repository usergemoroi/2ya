/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.lv$a
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.lv;
import com.yandex.mobile.ads.impl.mh1;

public final class j03
implements lv.a {
    public final lv a() {
        return mh1.e();
    }
}

