/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.dj2
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.dj2;
import org.jetbrains.annotations.Nullable;

public class dq1
extends dj2 {
    public dq1(@Nullable Exception exception) {
        super(exception);
    }

    public dq1(@Nullable String string2) {
        super(string2);
    }
}

