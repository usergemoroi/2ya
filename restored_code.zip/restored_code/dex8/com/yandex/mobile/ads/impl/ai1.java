/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.ib1
 *  com.yandex.mobile.ads.impl.nd2
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.ib1;
import com.yandex.mobile.ads.impl.nd2;
import org.jetbrains.annotations.NotNull;

public final class ai1
implements nd2 {
    @NotNull
    private final ib1 a;

    public ai1(@NotNull ib1 ib12) {
        this.a = ib12;
    }

    public final void a(long l10, long l11) {
        this.a.a(l10, l11);
    }
}

