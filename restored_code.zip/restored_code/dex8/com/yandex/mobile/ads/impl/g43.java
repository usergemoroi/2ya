/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.nb2
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.nb2;
import com.yandex.mobile.ads.impl.ta2;
import java.util.List;

public final class g43
implements nb2 {
    public final ta2 c;
    public final List d;

    public /* synthetic */ g43(ta2 ta22, List list) {
        this.c = ta22;
        this.d = list;
    }

    public final void a() {
        ta2.b(this.c, this.d);
    }
}

