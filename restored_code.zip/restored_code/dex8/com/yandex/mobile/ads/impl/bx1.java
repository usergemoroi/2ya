/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.ac1
 *  com.yandex.mobile.ads.impl.bc1
 *  com.yandex.mobile.ads.impl.i41
 */
package com.yandex.mobile.ads.impl;

import com.yandex.mobile.ads.impl.ac1;
import com.yandex.mobile.ads.impl.bc1;
import com.yandex.mobile.ads.impl.i41;
import com.yandex.mobile.ads.impl.n71;
import org.jetbrains.annotations.NotNull;

public final class bx1
implements bc1 {
    @NotNull
    public final ac1 a(@NotNull i41 i412) {
        return new n71(i412);
    }
}

