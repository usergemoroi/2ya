/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  com.yandex.mobile.ads.impl.d20
 */
package com.yandex.mobile.ads.impl;

import android.net.Uri;
import com.yandex.mobile.ads.impl.d20;
import org.jetbrains.annotations.NotNull;

public final class cz1
implements d20 {
    public final boolean a(@NotNull Uri uri) {
        return false;
    }
}

