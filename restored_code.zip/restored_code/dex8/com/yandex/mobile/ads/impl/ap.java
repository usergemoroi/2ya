/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  com.yandex.mobile.ads.impl.af0
 *  com.yandex.mobile.ads.impl.sp1$b
 *  com.yandex.mobile.ads.impl.t
 *  com.yandex.mobile.ads.impl.v
 *  com.yandex.mobile.ads.impl.xp1
 */
package com.yandex.mobile.ads.impl;

import android.view.View;
import com.yandex.mobile.ads.impl.af0;
import com.yandex.mobile.ads.impl.s51;
import com.yandex.mobile.ads.impl.sp1;
import com.yandex.mobile.ads.impl.t;
import com.yandex.mobile.ads.impl.v;
import com.yandex.mobile.ads.impl.xp1;
import org.jetbrains.annotations.NotNull;

public final class ap
implements v<t> {
    @NotNull
    private final xp1 a;
    @NotNull
    private final s51 b;

    public ap(@NotNull xp1 xp12, @NotNull s51 s512) {
        this.a = xp12;
        this.b = s512;
    }

    @NotNull
    public final af0 a(@NotNull View view, @NotNull t t11) {
        this.b.a();
        this.a.a(sp1.b.D);
        return new af0(false);
    }
}

