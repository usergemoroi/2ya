/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.div.core.images.LoadReference
 *  com.yandex.mobile.ads.impl.aj0$c
 *  com.yandex.mobile.ads.impl.dx
 */
package com.yandex.mobile.ads.impl;

import com.yandex.div.core.images.LoadReference;
import com.yandex.mobile.ads.impl.aj0;
import com.yandex.mobile.ads.impl.dx;

public final class hs2
implements LoadReference {
    public final aj0.c a;

    public /* synthetic */ hs2(aj0.c c10) {
        this.a = c10;
    }

    public final void cancel() {
        dx.b((aj0.c)this.a);
    }
}

