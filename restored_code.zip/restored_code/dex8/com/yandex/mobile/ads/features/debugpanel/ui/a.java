/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.yandex.mobile.ads.impl.ux
 *  kotlin.jvm.functions.l
 *  kotlin.jvm.internal.k
 *  kotlin.jvm.internal.v
 */
package com.yandex.mobile.ads.features.debugpanel.ui;

import com.yandex.mobile.ads.impl.bp0;
import com.yandex.mobile.ads.impl.ux;
import kotlin.jvm.functions.l;
import kotlin.jvm.internal.k;
import kotlin.jvm.internal.v;
import kotlin.k0;

final class a
extends v
implements l<ux, k0> {
    a(bp0 bp02) {
        super(1, (Object)bp02, bp0.class, "onAction", "onAction(Lcom/yandex/mobile/ads/features/debugpanel/ui/model/DebugPanelUiAction;)V", 0);
    }

    public final Object invoke(Object object) {
        object = (ux)object;
        ((bp0)((Object)((k)this).receiver)).a((ux)object);
        return k0.a;
    }
}

