/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  androidx.core.content.FileProvider
 */
package com.yandex.mobile.ads.features.debugpanel.data.local;

import androidx.core.content.FileProvider;
import kotlin.Metadata;

@Metadata(d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\u0003"}, d2={"Lcom/yandex/mobile/ads/features/debugpanel/data/local/DebugPanelFileProvider;", "Landroidx/core/content/FileProvider;", "()V", "mobileads_externalRelease"}, k=1, mv={1, 9, 0}, xi=48)
public final class DebugPanelFileProvider
extends FileProvider {
}

